# comfyui-deepseek
Implement deepseek API call 
https://api-docs.deepseek.com/

## Nodes
Provide three nodes
![Snipaste_2025-01-25_16-10-40](https://github.com/user-attachments/assets/bc42d24e-b101-4895-81b2-3b3243b69c43)

## Usage
You need to create a new api_key.txt file in the plugin directory and write your api key into the txt file
![Snipaste_2025-01-25_14-04-58](https://github.com/user-attachments/assets/943f1b8b-cf3d-4263-98cd-4180972e8c68)
