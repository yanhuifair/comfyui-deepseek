Implement deepseek API call
https://api-docs.deepseek.com/

<img width="518" alt="Snipaste_2025-01-24_15-33-07" src="https://github.com/user-attachments/assets/33757fa7-9e25-4089-8856-5b83ff6f43f2" />
